package com.example.readingisgood;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReadingIsGoodApplicationTests
{

    @Test
    void contextLoads()
    {
    }

}
