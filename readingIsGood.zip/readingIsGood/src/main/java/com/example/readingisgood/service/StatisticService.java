package com.example.readingisgood.service;

import com.example.readingisgood.model.Statistic;

public interface StatisticService
{
    Statistic createStatistic(Statistic statistic);
}
