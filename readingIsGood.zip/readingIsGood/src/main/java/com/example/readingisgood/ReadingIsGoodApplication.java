package com.example.readingisgood;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReadingIsGoodApplication
{

    public static void main(String[] args)
    {
        SpringApplication.run(ReadingIsGoodApplication.class, args);
    }

}
